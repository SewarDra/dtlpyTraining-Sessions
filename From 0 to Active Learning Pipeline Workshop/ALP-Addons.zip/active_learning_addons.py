from multiprocessing.pool import ThreadPool
import pandas as pd
import dtlpy as dl
import datetime
import logging
import tqdm
import time
import sys
import os

logger = logging.getLogger(name=__name__)

if os.name == 'nt':
    logging.basicConfig()
    logger = logging.getLogger(name=__name__)
    logger.setLevel('DEBUG')
else:
    logger = logging.getLogger(name=__name__)


class ServiceRunner(dl.BaseServiceRunner):
    def __init__(self):
        """
        Init Service attributes here

        :return:
        """

    @staticmethod
    def update_train_time(model: dl.Model, dataset: dl.Dataset):
        dataset.metadata['lastTrainTime'] = datetime.datetime.utcnow().isoformat()
        dataset.update()
        return model

    @staticmethod
    def have_new_items(model: dl.Model, dataset: dl.Dataset, item_count_threshold, progress: dl.Progress):
        items_found = None
        progress.update(action='enough_items')
        if item_count_threshold is not None:
            try:
                last_train_time = dataset.metadata['lastTrainTime']
            except KeyError:
                last_train_time = None

            filters = dl.Filters()
            filters.page_size = 1

            if last_train_time is not None:
                filters.add(field='createdAt', values=last_train_time, operator=dl.FiltersOperations.GREATER_THAN)

            pages = dataset.items.list(filters=filters)
            items_found = pages.items_count
            # Count the items
            print('Number of items in dataset: {}'.format(items_found))
            if items_found < item_count_threshold:
                progress.update(action='not_enough_items')

        return model, items_found

    @staticmethod
    def action_per_classification(item: dl.Item, progress: dl.Progress):
        filters = dl.Filters(resource=dl.FiltersResource.ANNOTATION,
                             field=dl.KnownFields.TYPE,
                             values=dl.AnnotationType.CLASSIFICATION)
        for retry in range(10):
            annotations = item.annotations.list(filters=filters)
            if len(annotations) == 1:
                if annotations[0].label in ['nozzle unknown', 'nozzle in tank', 'nozzle outside tank']:
                    progress.update(action=annotations[0].label)
                    break
                else:
                    print('Unknown label: {}'.format(annotations[0].label))
                    progress.update(action='unknown')
                    break
            else:
                print(f'only one annotation is allowed - found {len(annotations)}')
                progress.update(action='unknown')
                time.sleep(1)

        return item

    @staticmethod
    def item_status(report: dict, item: dl.Item, pbar):
        try:
            tag = list(item.metadata['system']['tags'].keys())[0]
        except (KeyError, IndexError):
            tag = 'NA'

        report[item.id] = {'Item Name': item.name, 'Item ID': item.id,
                           'Item Type': tag}

        if pbar is not None:
            pbar.update()
        return report

    @staticmethod
    def generate_train_report(model: dl.Model):
        dataset = model.dataset
        pages = dataset.items.list()
        pbar = tqdm.tqdm(total=pages.items_count, file=sys.stdout)
        pool = ThreadPool(processes=128)
        report = dict()
        for page in pages:
            for item in page:
                pool.apply_async(func=ServiceRunner.item_status,
                                 kwds={'report': report, 'item': item, 'pbar': pbar})
        pool.close()
        pool.join()
        pool.terminate()

        data = []
        for key in report:
            data.append(list(report[key].values()))

        df = pd.DataFrame(data, columns=['Item Name', 'Item ID', 'Item Type'])
        filename = f'train_{model.id}_{model.name}_in-progress.csv'
        df.to_csv(filename, index=False)
        dataset.items.upload(local_path=filename,
                                      remote_path='/Train Reports',
                                      remote_name=filename)


    @staticmethod
    def finalize_report(model: dl.Model):
        dataset = model.dataset
        filepath = f'/Train Reports/train_{model.id}_{model.name}_in-progress.csv'
        try:
            item = dataset.items.get(filepath=filepath)
            updated_filepath = f'/Train Reports/train_{model.id}_{model.name}.csv'
            item.move(new_path=updated_filepath)
        except dl.exceptions.NotFound:
            raise dl.exceptions.NotFound(f'Could not find file {filepath} in dataset {dataset.name}')

    @staticmethod
    def annotation_validation(item: dl.Item, context: dl.Context, progress: dl.Progress):
        progress.update(action='no_update')
        filters = dl.Filters(resource=dl.FiltersResource.ANNOTATION, use_defaults=False)
        filters.add(field=dl.KnownFields.TYPE, values=dl.AnnotationType.CLASSIFICATION)
        annotations = item.annotations.list(filters=filters)
        task_name = "Cant get task name from context"
        if context is not None and context.task is not None:
            task_name = context.task.name.lower()

        logger.info(f'Annotation validation for item {item.name} in task {task_name}')

        if len(annotations) == 1:
            if annotations[0].label not in task_name:
                progress.update(action='updated')
            return item
        else:
            automated_annotations = []
            manual_annotations = []
            for annotation in annotations:
                if annotation.automated:
                    automated_annotations.append(annotation)
                else:
                    manual_annotations.append(annotation)

            if len(manual_annotations) > 1:
                manual_annotations[0].update_status(status=dl.AnnotationStatus.ISSUE)
                logger.info(f'Annotation {manual_annotations[0].id} for item {item.name} in task {task_name} '
                            f'has been marked as an issue due to multiple manual annotations')
                progress.update(action='issue')
                return item
            elif len(automated_annotations) != 0 and len(manual_annotations) == 1:
                for auto in automated_annotations:
                    item.annotations.delete(annotation_id=auto.id)
            if manual_annotations[0].label not in task_name:
                progress.update(action='updated')
            return item


def deploy(project_name, upload_package):
    project = dl.projects.get(project_name=project_name)
    package_name = 'active-learning-addons'

    modules = [dl.PackageModule(
        name=package_name,
        class_name='ServiceRunner',
        entry_point='active_learning_addons.py',
        functions=[dl.PackageFunction(name='action_per_classification',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_ITEM, name='item')],
                                      outputs=[dl.FunctionIO(type=dl.PackageInputType.ITEM,
                                                             name='item',
                                                             actions=['nozzle unknown',
                                                                      'nozzle in tank',
                                                                      'nozzle outside tank',
                                                                      'unknown'])],
                                      ),
                   dl.PackageFunction(name='update_train_time',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL, name='model'),
                                              dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_DATASET, name='dataset')],
                                      outputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL, name='model')],
                                      ),
                   dl.PackageFunction(name='have_new_items',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL, name='model'),
                                              dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_DATASET, name='dataset'),
                                              dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_INT,
                                                            name='item_count_threshold')],
                                      outputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL,
                                                             name='model',
                                                             actions=['enough_items', 'not_enough_items']
                                                             ),
                                               dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_INT, name='items_found')],
                                      ),
                   dl.PackageFunction(name='generate_train_report',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL, name='model')],
                                      ),
                   dl.PackageFunction(name='finalize_report',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_MODEL, name='model')]
                                      ),
                   dl.PackageFunction(name='annotation_validation',
                                      inputs=[dl.FunctionIO(type=dl.PACKAGE_INPUT_TYPE_ITEM, name='item')],
                                      outputs=[dl.FunctionIO(type=dl.PackageInputType.ITEM,
                                                             name='item',
                                                             actions=['no_update', 'updated', 'issue']
                                                             )]
                                      )
                   ])]

    if upload_package:
        package = project.packages.push(package_name=package_name,
                                        modules=modules,
                                        service_config={
                                            'runtime': dl.KubernetesRuntime(
                                                concurrency=10,
                                                autoscaler=dl.KubernetesRabbitmqAutoscaler(
                                                    min_replicas=0,
                                                    max_replicas=1,
                                                    queue_length=100
                                                )).to_json()},
                                        src_path='.')
        print("package has been deployed: ", package.name)
    else:
        package = project.packages.get(package_name=package_name)
        print("package has been gotten: ", package.name)
    #################
    # create service #
    #################

    try:
        service = package.services.get(service_name=package.name)
        print("service has been gotten: ", service.name)
    except dl.exceptions.NotFound:
        service = package.services.deploy(service_name=package.name,
                                          module_name=package_name)
        print("service has been deployed: ", service.name)

    print("package.version: ", package.version)
    print("service.package_revision: ", service.package_revision)
    print("service.runtime.concurrency: ", service.runtime.concurrency)
    service.runtime.autoscaler.print()

    if package.version != service.package_revision:
        service.package_revision = package.version
        service.update(force=True)
        print("service.package_revision has been updated: ", service.package_revision)


def testing_generate_report():
    s = ServiceRunner()
    model = dl.models.get(model_id='654ceae17d73a01a4ffa7393')
    s.generate_train_report(model=model)


def testing_finalize_report():
    s = ServiceRunner()
    model = dl.models.get(model_id='654ceae17d73a01a4ffa7393')
    s.finalize_report(model=model)


def test_train_start():
    model = dl.models.get(model_id='654a06d3c94c1760d66c20d6')
    dataset = dl.datasets.get(dataset_id='6548e936c9c3aed0f28e1ee0')
    s = ServiceRunner()
    s.have_new_items(model=model, dataset=dataset, item_count_threshold=None, progress=dl.Progress())


def test_annotation_validation():
    item = dl.items.get(item_id='6554a71d5dfe557e790c3458')
    srr = ServiceRunner()
    srr.annotation_validation(item=item, context=dl.Context(), progress=dl.Progress())


if __name__ == "__main__":
    deploy(project_name="Google Workshop", upload_package=True)
    # test_train_start()
    # For debugging
    # testing_finalize_report()
    # test_annotation_validation()
